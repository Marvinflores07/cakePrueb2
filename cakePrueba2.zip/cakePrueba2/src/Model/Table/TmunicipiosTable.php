<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * Tmunicipios Model
 *
 * @property \App\Model\Table\TDepartamentosTable|\Cake\ORM\Association\BelongsTo $TDepartamentos
 * @property \App\Model\Table\PersonasTable|\Cake\ORM\Association\HasMany $Personas
 *
 * @method \App\Model\Entity\Tmunicipio get($primaryKey, $options = [])
 * @method \App\Model\Entity\Tmunicipio newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\Tmunicipio[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\Tmunicipio|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Tmunicipio patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\Tmunicipio[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\Tmunicipio findOrCreate($search, callable $callback = null, $options = [])
 */
class TmunicipiosTable extends Table
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('tmunicipios');
        $this->setDisplayField('nombre');
        $this->setPrimaryKey('id');
         $this->belongsTo('tdepartamentos', [
            'foreignKey' => 'tdepartamento_id',
            'joinType' => 'INNER'
        ]);
        $this->hasMany('Personas', [
            'foreignKey' => 'tmunicipio_id'
        ]);

    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('id')
            ->allowEmpty('id', 'create');

        $validator
            ->requirePresence('nombre', 'create')
            ->notEmpty('nombre');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules)
    {
        $rules->add($rules->existsIn(['tdepartamento_id'], 'TDepartamentos'));

        return $rules;
    }
}
