<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * Tmunicipios Controller
 *
 * @property \App\Model\Table\TmunicipiosTable $Tmunicipios
 *
 * @method \App\Model\Entity\Tmunicipio[] paginate($object = null, array $settings = [])
 */
class TmunicipiosController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['tdepartamentos']
        ];
        $tmunicipios = $this->paginate($this->Tmunicipios);

        $this->set(compact('tmunicipios'));
        $this->set('_serialize', ['tmunicipios']);
    }

    /**
     * View method
     *
     * @param string|null $id Tmunicipio id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $tmunicipio = $this->Tmunicipios->get($id, [
            'contain' => ['TDepartamentos', 'Personas']
        ]);

        $this->set('tmunicipio', $tmunicipio);
        $this->set('_serialize', ['tmunicipio']);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $tmunicipio = $this->Tmunicipios->newEntity();
        if ($this->request->is('post')) {
            $tmunicipio = $this->Tmunicipios->patchEntity($tmunicipio, $this->request->getData());
            if ($this->Tmunicipios->save($tmunicipio)) {
                    $this->Flash->success(__('The tmunicipio has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The tmunicipio could not be saved. Please, try again.'));
        }
        $tdepartamentos = $this->Tmunicipios->Tdepartamentos->find('list', ['limit' => 200]);
        $this->set(compact('tmunicipio', 'tdepartamentos'));
        $this->set('_serialize', ['tmunicipio']);
        $this->viewBuilder()->setLayout( 'layout2');
    }

    /**
     * Edit method
     *
     * @param string|null $id Tmunicipio id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $tmunicipio = $this->Tmunicipios->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $tmunicipio = $this->Tmunicipios->patchEntity($tmunicipio, $this->request->getData());
            if ($this->Tmunicipios->save($tmunicipio)) {
                $this->Flash->success(__('The tmunicipio has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The tmunicipio could not be saved. Please, try again.'));
        }
        $tdepartamentos = $this->Tmunicipios->tdepartamentos->find('list', ['limit' => 200]);
        $this->set(compact('tmunicipio', 'tdepartamentos'));
        $this->set('_serialize', ['tmunicipio']);
        $this->viewBuilder()->setLayout( 'layout2');
    }

    /**
     * Delete method
     *
     * @param string|null $id Tmunicipio id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $tmunicipio = $this->Tmunicipios->get($id);
        if ($this->Tmunicipios->delete($tmunicipio)) {
            $this->Flash->success(__('The tmunicipio has been deleted.'));
        } else {
            $this->Flash->error(__('The tmunicipio could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
