<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * Tidiomas Controller
 *
 * @property \App\Model\Table\TidiomasTable $Tidiomas
 *
 * @method \App\Model\Entity\Tidioma[] paginate($object = null, array $settings = [])
 */
class TidiomasController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $tidiomas = $this->paginate($this->Tidiomas);

        $this->set(compact('tidiomas'));
        $this->set('_serialize', ['tidiomas']);
    }

    /**
     * View method
     *
     * @param string|null $id Tidioma id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $tidioma = $this->Tidiomas->get($id, [
            'contain' => []
        ]);

        $this->set('tidioma', $tidioma);
        $this->set('_serialize', ['tidioma']);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $tidioma = $this->Tidiomas->newEntity();
        if ($this->request->is('post')) {
            $tidioma = $this->Tidiomas->patchEntity($tidioma, $this->request->getData());
            if ($this->Tidiomas->save($tidioma)) {
                $this->Flash->success(__('The tidioma has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The tidioma could not be saved. Please, try again.'));
        }
        $this->set(compact('tidioma'));
        $this->set('_serialize', ['tidioma']);
    }

    /**
     * Edit method
     *
     * @param string|null $id Tidioma id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $tidioma = $this->Tidiomas->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $tidioma = $this->Tidiomas->patchEntity($tidioma, $this->request->getData());
            if ($this->Tidiomas->save($tidioma)) {
                $this->Flash->success(__('The tidioma has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The tidioma could not be saved. Please, try again.'));
        }
        $this->set(compact('tidioma'));
        $this->set('_serialize', ['tidioma']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Tidioma id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $tidioma = $this->Tidiomas->get($id);
        if ($this->Tidiomas->delete($tidioma)) {
            $this->Flash->success(__('The tidioma has been deleted.'));
        } else {
            $this->Flash->error(__('The tidioma could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
