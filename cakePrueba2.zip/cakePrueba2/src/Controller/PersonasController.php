<?php
namespace App\Controller;

use App\Controller\AppController;
use Symfony\Component\Debug\Debug;

/**
 * Personas Controller
 *
 * @property \App\Model\Table\PersonasTable $Personas
 *
 * @method \App\Model\Entity\Persona[] paginate($object = null, array $settings = [])
 */
class PersonasController extends AppController
{

    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Users', 'Tmunicipios']
        ];
        $personas = $this->paginate($this->Personas);

        $this->set(compact('personas'));
        $this->set('_serialize', ['personas']);
    }

    /**
     * View method
     *
     * @param string|null $id Persona id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $persona = $this->Personas->get($id, [
            'contain' => ['Users', 'Tmunicipios', 'Tidiomas']
        ]);

        $this->set('persona', $persona);
        $this->set('_serialize', ['persona']);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $persona = $this->Personas->newEntity();
        if ($this->request->is('post')) {
            $persona = $this->Personas->patchEntity($persona, $this->request->getData());
//debug($this->request->getData());

            if ($this->Personas->save($persona)) {

                $this->Flash->success(__('The persona has been saved.'));
                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The persona could not be saved. Please, try again.'));
        }
        $users = $this->Personas->Users->find('list', ['limit' => 200]);
        $tidiomas = $this->Personas->Tidiomas->find('list');

        $tdepartamentos = $this->Personas->Tmunicipios->Tdepartamentos->find('list');
        $this->set(compact('persona', 'users','tdepartamentos', 'tidiomas'));
        $this->set('_serialize', ['persona']);
        $this->viewBuilder()->setLayout( 'layout2');
    }

 public function getByMunicipio() {

        $data=$this->Personas->Tmunicipios->find('list',
            ['conditions' =>
                ['Tmunicipios.tdepartamento_id' => $_POST['dato']]
            ]);

        echo json_encode($data);
        $this->autoRender=false;
    }
    public function newIdioma() {

        $tidiomas= $this->Personas->Tidiomas->find('list');
        $leng=$_GET['leng'];
        $this->set(compact('leng',$leng,'tidiomas',$tidiomas));
        $this->render('/Personas/newIdioma');
    }

    

    /**
     * Edit method
     *
     * @param string|null $id Persona id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Network\Exception\NotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $persona = $this->Personas->get($id, [
            'contain' => ['Tidiomas']
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $persona = $this->Personas->patchEntity($persona, $this->request->getData());
            if ($this->Personas->save($persona)) {
                $this->Flash->success(__('The persona has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The persona could not be saved. Please, try again.'));
        }
        $users = $this->Personas->Users->find('list', ['limit' => 200]);
        $tmunicipios = $this->Personas->Tmunicipios->find('list', ['limit' => 200]);
        $tidiomas = $this->Personas->Tidiomas->find('list', ['limit' => 200]);
        $this->set(compact('persona', 'users', 'tmunicipios', 'tidiomas'));
        $this->set('_serialize', ['persona']);
    }

    /**
     * Delete method
     *
     * @param string|null $id Persona id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $persona = $this->Personas->get($id);
        if ($this->Personas->delete($persona)) {
            $this->Flash->success(__('The persona has been deleted.'));
        } else {
            $this->Flash->error(__('The persona could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
