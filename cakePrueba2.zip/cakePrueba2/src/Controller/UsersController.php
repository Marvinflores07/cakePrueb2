<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * Users Controller
 *
 */
class UsersController extends AppController
{
	public function index()
	{

	  $users=$this->paginate($this->Users,['limit'=>10]);
	  $this->set("users",$users);
	}

	public function add()
	{
	$user=$this->Users->newEntity();
	if($this->request->is('post'))
	{
		$user=$this->Users->patchEntity($user,$this->request->data);
		if($this->Users->save($user))
		{
			$this->Flash->success('El usuario ha sido guardado');
            $this->redirect(array('action' => 'index'));
		}
		else{
            $this->Flash->error('Eror');
		}
	}
        $this->set(compact('user'));

	}
}
