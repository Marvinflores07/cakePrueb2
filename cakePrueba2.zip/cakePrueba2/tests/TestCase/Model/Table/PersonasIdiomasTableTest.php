<?php
namespace App\Test\TestCase\Model\Table;

use App\Model\Table\PersonasIdiomasTable;
use Cake\ORM\TableRegistry;
use Cake\TestSuite\TestCase;

/**
 * App\Model\Table\PersonasIdiomasTable Test Case
 */
class PersonasIdiomasTableTest extends TestCase
{

    /**
     * Test subject
     *
     * @var \App\Model\Table\PersonasIdiomasTable
     */
    public $PersonasIdiomas;

    /**
     * Fixtures
     *
     * @var array
     */
    public $fixtures = [
        'app.personas_idiomas',
        'app.personas',
        'app.users',
        'app.user_roles',
        'app.tmunicipios',
        'app.tdepartamentos',
        'app.tidiomas'
    ];

    /**
     * setUp method
     *
     * @return void
     */
    public function setUp()
    {
        parent::setUp();
        $config = TableRegistry::exists('PersonasIdiomas') ? [] : ['className' => PersonasIdiomasTable::class];
        $this->PersonasIdiomas = TableRegistry::get('PersonasIdiomas', $config);
    }

    /**
     * tearDown method
     *
     * @return void
     */
    public function tearDown()
    {
        unset($this->PersonasIdiomas);

        parent::tearDown();
    }

    /**
     * Test initialize method
     *
     * @return void
     */
    public function testInitialize()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test validationDefault method
     *
     * @return void
     */
    public function testValidationDefault()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test buildRules method
     *
     * @return void
     */
    public function testBuildRules()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
