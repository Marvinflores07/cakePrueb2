<?php
namespace App\Test\TestCase\Model\Table;

use App\Model\Table\PersonaIdiomasTable;
use Cake\ORM\TableRegistry;
use Cake\TestSuite\TestCase;

/**
 * App\Model\Table\PersonaIdiomasTable Test Case
 */
class PersonaIdiomasTableTest extends TestCase
{

    /**
     * Test subject
     *
     * @var \App\Model\Table\PersonaIdiomasTable
     */
    public $PersonaIdiomas;

    /**
     * Fixtures
     *
     * @var array
     */
    public $fixtures = [
        'app.persona_idiomas',
        'app.personas',
        'app.users',
        'app.user_roles',
        'app.tmunicipios',
        'app.tdepartamentos',
        'app.tidiomas',
        'app.personas_tidiomas'
    ];

    /**
     * setUp method
     *
     * @return void
     */
    public function setUp()
    {
        parent::setUp();
        $config = TableRegistry::exists('PersonaIdiomas') ? [] : ['className' => PersonaIdiomasTable::class];
        $this->PersonaIdiomas = TableRegistry::get('PersonaIdiomas', $config);
    }

    /**
     * tearDown method
     *
     * @return void
     */
    public function tearDown()
    {
        unset($this->PersonaIdiomas);

        parent::tearDown();
    }

    /**
     * Test initialize method
     *
     * @return void
     */
    public function testInitialize()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test validationDefault method
     *
     * @return void
     */
    public function testValidationDefault()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test buildRules method
     *
     * @return void
     */
    public function testBuildRules()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
