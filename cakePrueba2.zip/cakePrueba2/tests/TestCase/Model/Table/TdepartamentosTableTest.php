<?php
namespace App\Test\TestCase\Model\Table;

use App\Model\Table\TdepartamentosTable;
use Cake\ORM\TableRegistry;
use Cake\TestSuite\TestCase;

/**
 * App\Model\Table\TdepartamentosTable Test Case
 */
class TdepartamentosTableTest extends TestCase
{

    /**
     * Test subject
     *
     * @var \App\Model\Table\TdepartamentosTable
     */
    public $Tdepartamentos;

    /**
     * Fixtures
     *
     * @var array
     */
    public $fixtures = [
        'app.tdepartamentos',
        'app.tmunicipios',
        'app.t_departamentos',
        'app.personas'
    ];

    /**
     * setUp method
     *
     * @return void
     */
    public function setUp()
    {
        parent::setUp();
        $config = TableRegistry::exists('Tdepartamentos') ? [] : ['className' => TdepartamentosTable::class];
        $this->Tdepartamentos = TableRegistry::get('Tdepartamentos', $config);
    }

    /**
     * tearDown method
     *
     * @return void
     */
    public function tearDown()
    {
        unset($this->Tdepartamentos);

        parent::tearDown();
    }

    /**
     * Test initialize method
     *
     * @return void
     */
    public function testInitialize()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test validationDefault method
     *
     * @return void
     */
    public function testValidationDefault()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
